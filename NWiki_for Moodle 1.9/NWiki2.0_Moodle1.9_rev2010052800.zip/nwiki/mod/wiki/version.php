<?php // $Id: version.php,v 1.31 2010/05/28 09:49:34 pigui Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2010052800;
$module->requires = 2007020200;  // Requires this Moodle version. 1.8 or newer
$module->cron     = 0; // How often should cron check this module (seconds)?

?>
